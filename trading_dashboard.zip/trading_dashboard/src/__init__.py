"""Backend modular para Quantum & MLOps Governance Terminal."""
